export const collectionData =  [
    {
        id: 1,
        kind: 'catug1',
        class: 'work-1',
        catugName: 'Graphic Design'
    },
    {
        id: 2,
        kind: 'catug2',
        class: 'work-2',
        catugName: 'Apps'
    },
    {
        id: 3,
        kind: 'catug3',
        class: 'work-3',
        catugName: 'Software'
    },
    {
        id: 4,
        kind: 'catug1',
        class: 'work-4',
        catugName: 'Graphic Design'
    },
    {
        id: 5,
        kind: 'catug2',
        class: 'work-5',
        catugName: 'Apps'
    },
    {
        id: 6,
        kind: 'catug3',
        class: 'work-6',
        catugName: 'Software'
    }
];